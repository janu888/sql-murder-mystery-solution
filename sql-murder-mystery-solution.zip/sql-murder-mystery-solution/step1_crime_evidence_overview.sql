SELECT evidence_id, room, description, found_time
FROM evidence
ORDER BY found_time;
