SELECT * FROM keycard_logs
WHERE employee_id = 4
ORDER BY entry_time;
